export class Customer {
  id: number;
  customerCode: string;
  customerName: string;
  serviceType: string;
  currency: string;
  balance: number;
  vigilance: number

}
