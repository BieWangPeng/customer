import {Customer} from './customer';

export class Customers {
  customers:Customer[];

}